package com.example.hanif;

public class ModelClass {

    String name;

    public ModelClass(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
