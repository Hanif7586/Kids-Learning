package com.example.hanif;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FlowerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flower);
    }
}